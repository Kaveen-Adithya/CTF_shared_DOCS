import { NextResponse } from 'next/server'
import { loginSchema, genericAuthError } from '@/lib/security'
import { audit } from '@/lib/audit'
export async function POST(request: Request) { const requestId = crypto.randomUUID(); const parsed = loginSchema.safeParse(await request.json().catch(()=>null)); if (!parsed.success) return NextResponse.json({ error: genericAuthError() }, { status: 401 }); audit({requestId,eventType:'login_failed',endpoint:'/api/auth/login',method:'POST',statusCode:401}); return NextResponse.json({ error: genericAuthError() }, { status: 401 }) }
