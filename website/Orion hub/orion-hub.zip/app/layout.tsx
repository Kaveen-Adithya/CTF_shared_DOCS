import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'OrionTech Solutions | OrionHub',
  description: 'Reliable technology services and secure customer operations from OrionTech Solutions.',
}

export const viewport: Viewport = { colorScheme: 'light', themeColor: '#102a43' }

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" className="bg-background"><body>{children}</body></html>
}
