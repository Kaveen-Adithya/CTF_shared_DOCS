export type AuditEvent = { requestId: string; eventType: string; endpoint: string; method: string; statusCode: number; userId?: string; role?: string; ipAddress?: string }
export function audit(event: AuditEvent) { const safeEvent = { timestamp: new Date().toISOString(), ...event }; console.info(JSON.stringify(safeEvent)) }
