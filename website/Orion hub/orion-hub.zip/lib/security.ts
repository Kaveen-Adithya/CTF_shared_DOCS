import { z } from 'zod'

export const loginSchema = z.object({ username: z.string().trim().min(1).max(120), password: z.string().min(1).max(200), portal: z.enum(['customer','staff']) })
export const supportTicketSchema = z.object({ subject: z.string().trim().min(3).max(160), category: z.enum(['Technical Support','Billing','Security','Account','Other']), priority: z.enum(['LOW','MEDIUM','HIGH']), description: z.string().trim().min(10).max(5000) })
export const paymentSchema = z.object({ invoiceId: z.string().uuid(), method: z.enum(['Demo Card','Demo Bank Transfer','Demo Wallet']) })
export const urlPreviewSchema = z.object({ url: z.string().url().max(2048) })
const privateHostPattern = /(^localhost$|\.local$|\.internal$|^127\.|^10\.|^192\.168\.|^172\.(1[6-9]|2\d|3[0-1])\.)/i
export function validatePreviewUrl(value: string) { const url = new URL(value); if (!['http:','https:'].includes(url.protocol)) throw new Error('Unsupported URL scheme'); if (url.username || url.password) throw new Error('Credentials are not allowed'); if (privateHostPattern.test(url.hostname) || url.hostname === '::1') throw new Error('Private hosts are not allowed'); return url }
export const MAX_FAILED_LOGIN_ATTEMPTS = 5
export const LOCKOUT_MINUTES = 15
export function genericAuthError() { return 'Invalid username or password.' }
