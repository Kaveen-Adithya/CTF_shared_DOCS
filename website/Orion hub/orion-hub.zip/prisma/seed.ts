import argon2 from 'argon2'

type PrismaModule = { PrismaClient: new () => { user: { upsert: (args: unknown) => Promise<unknown> }; $disconnect: () => Promise<void> } }
const { PrismaClient } = require('@prisma/client') as PrismaModule
const prisma = new PrismaClient()
async function main(){const passwordHash=await argon2.hash('OrionDemo-2026!',{type:argon2.argon2id}); await prisma.user.upsert({where:{username:'john'},update:{},create:{username:'john',email:'john@example.local',passwordHash,role:'CUSTOMER',customerProfile:{create:{fullName:'John Perera',organization:'Perera & Co.'}}}}); await prisma.user.upsert({where:{username:'sarah.staff'},update:{},create:{username:'sarah.staff',passwordHash,role:'STAFF',staffProfile:{create:{fullName:'Sarah Fernando',staffId:'OT-STF-001'}}}}); await prisma.user.upsert({where:{username:'admin'},update:{},create:{username:'admin',passwordHash,role:'ADMIN',staffProfile:{create:{fullName:'Orion Administrator',staffId:'OT-ADM-001'}}}})}
main().finally(()=>prisma.$disconnect())
